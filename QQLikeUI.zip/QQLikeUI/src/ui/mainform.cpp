#include "mainform.h"
#include "ui_mainform.h"

#include "collapseview.h"

MainForm::MainForm(QWidget *parent) :
    MoveableFramelessWindow(parent),
    ui(new Ui::MainForm)
{
    ui->setupUi(this);

     ui->page_4->layout()->addWidget(new CollapseView());
}

MainForm::~MainForm()
{
    delete ui;
}

QWidget *MainForm::getDragnWidget()
{
    return ui->main_top;
}
